# 商机项目台账上传脚本使用说明

## 1. 文件准备

请把以下文件放在同一个文件夹中：

```text
import_opportunity_ledger_standalone.py
requirement.txt
2025学年商机项目台账.xlsx
```

Excel 文件名建议包含“商机项目台账”，例如：

```text
2025学年商机项目台账.xlsx
```

如果同一文件夹里有多个 `.xlsx` 文件，运行时需要用 `--input` 指定具体文件。

## 2. 安装 Python 依赖

先确认电脑已安装 Python 3.10 或更高版本。

在脚本所在文件夹打开终端，然后执行：

```powershell
pip install -r requirement.txt
```

## 3. Supabase 配置

脚本中已经内置上传数据所需的 Supabase 配置，一般不需要额外填写环境变量。

注意：该脚本包含数据库上传密钥，请只发给可信人员，不要公开转发或提交到公开代码仓库。

## 4. 先试运行

正式上传前，建议先执行：

```powershell
python import_opportunity_ledger_standalone.py --dry-run
```

这个命令只会读取和解析 Excel，不会写入数据库。

看到类似结果表示解析成功：

```text
Prepared 1 sheets and 22 rows.
Dry run complete. No data written.
```

## 5. 正式上传

确认试运行无误后执行：

```powershell
python import_opportunity_ledger_standalone.py --confirm
```

脚本会按每个 sheet 对应的快照日期，先删除数据库中同日期的旧数据，再写入 Excel 中的新数据。

## 6. 指定 Excel 文件

如果 Excel 不在脚本同目录，或同目录下有多个 Excel，可以手动指定：

```powershell
python import_opportunity_ledger_standalone.py --input "2025学年商机项目台账.xlsx" --dry-run
python import_opportunity_ledger_standalone.py --input "2025学年商机项目台账.xlsx" --confirm
```

## 7. 常见问题

### 缺少依赖

如果提示找不到 `pandas`、`openpyxl` 或 `httpx`，重新执行：

```powershell
pip install -r requirement.txt
```

### 找不到 Excel

如果提示找不到 `.xlsx` 文件，请确认 Excel 和脚本在同一文件夹，或使用 `--input` 指定文件。

### sheet 名称无法解析日期

sheet 名需要是 4 位数字日期格式，例如：

```text
0423
0915
```

脚本会根据 Excel 文件名中的学年推断年份，例如 `2025学年商机项目台账.xlsx` 中的 `0423` 会解析为 `2026-04-23`。
